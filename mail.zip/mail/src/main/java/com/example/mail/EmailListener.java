package com.example.mail;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import javax.mail.*;
import javax.mail.event.MessageCountAdapter;
import javax.mail.event.MessageCountEvent;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class EmailListener {

    private static final String HOST = "imap.gmail.com";
    private static final String USERNAME = "";
    private static final String PASSWORD = "";

    public static void main(String[] args) {
        Properties properties = new Properties();
        properties.put("mail.store.protocol", "imaps");
        properties.put("mail.imap.host", HOST);
        properties.put("mail.imap.port", "993");
        properties.put("mail.imap.ssl.enable", "true");

        try {
            Session emailSession = Session.getDefaultInstance(properties);
            Store store = emailSession.getStore("imaps");
            store.connect(HOST, USERNAME, PASSWORD);

            Folder inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_WRITE);

            inbox.addMessageCountListener(new MessageCountAdapter() {
                @Override
                public void messagesAdded(MessageCountEvent event) {
                    Message[] messages = event.getMessages();
                    for (Message message : messages) {
                        try {
                            processMessage((MimeMessage) message);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });

            while (true) {
                inbox.getMessageCount(); // This will trigger the listener
                Thread.sleep(1000);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void processMessage(MimeMessage message) throws Exception {
        String subject = message.getSubject();
        String body = getTextFromMessage(message);
        System.out.println("Subject: " + subject);
        System.out.println("Body: " + body);

        if (message.getContent() instanceof Multipart) {
            Multipart multipart = (Multipart) message.getContent();
            for (int i = 0; i < multipart.getCount(); i++) {
                MimeBodyPart part = (MimeBodyPart) multipart.getBodyPart(i);
                if (Part.ATTACHMENT.equalsIgnoreCase(part.getDisposition())) {
                    saveAttachment(part);
                }
            }
        }

        // Forward the message details to Kafka
        System.out.println(subject);
        System.out.println(body);
       // sendMessageToKafka(subject, body);
    }

    private static String getTextFromMessage(Message message) throws Exception {
        if (message.getContent() instanceof String) {
            return (String) message.getContent();
        } else if (message.getContent() instanceof MimeMultipart) {
            MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
            return getTextFromMimeMultipart(mimeMultipart);
        }
        return "";
    }

    private static String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws Exception {
        StringBuilder result = new StringBuilder();
        int count = mimeMultipart.getCount();
        for (int i = 0; i < count; i++) {
            BodyPart bodyPart = mimeMultipart.getBodyPart(i);
            if (bodyPart.isMimeType("text/plain")) {
                result.append(bodyPart.getContent());
            } else if (bodyPart.isMimeType("text/html")) {
                String html = (String) bodyPart.getContent();
                result.append(org.jsoup.Jsoup.parse(html).text());
            }
        }
        return result.toString();
    }

    private static void saveAttachment(BodyPart part) throws IOException, MessagingException {
        String destFilePath = "/path/to/save/attachments/" + part.getFileName();
        File file = new File(destFilePath);
        try (FileOutputStream output = new FileOutputStream(file)) {
            output.write(part.getInputStream().readAllBytes());
        }
    }

    private static void sendMessageToKafka(String subject, String body) {
        // Implement Kafka producer to send message to Kafka topic
        KafkaProducer<String, String> producer = new KafkaProducer<>(getKafkaProperties());
        ProducerRecord<String, String> record = new ProducerRecord<>("email-topic", subject, body);
        producer.send(record);
        producer.close();
    }

    private static Properties getKafkaProperties() {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        return props;
    }
}
